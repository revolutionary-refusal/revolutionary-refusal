IAAAP evidence archive — 2026-11-25
Original user-supplied files, unchanged.
EPA site profile print snapshot: temp5624197532068140099.PDF
Army plume advisory: pdf_78382.pdf
Army claims brochure: pdf_78387.pdf
Images: supplied screenshots, original filenames.
Live site download attempted but DNS resolution failed. No live HTML or eight-document EPA repository archive is included.
Sources to preserve:
https://response.epa.gov/site/site_profile.aspx?site_id=17211
https://response.epa.gov/site/doc_list.aspx?site_id=17211
https://www.army.mil/asc#org-iowa-army-ammunition-plant
https://epa.illinois.gov/iowa-plant-updates.html
https://epa.illinois.gov/about-us/illinois-epa-news/il-prepares-for-planned-detonation-at-iaaap.html
Hashes establish integrity of supplied copies, not authenticity or completeness of live sites.
